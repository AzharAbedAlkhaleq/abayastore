
@extends('admin.layouts.app')
@section('content')
<div class="card">
    <div style="background-color:lavender" class="card-header">

        <h1 style=" color:rgb(151, 35, 35); text-align:center; font-size:50px;margin-top:20px">{{ trans('admin.order details') }} </h1>
    </div>
<div>
    
    <div  class="card-body">
        @if (session()->has('success'))
        <div class="alert alert-success text-center mt-4">
            {{session()->get('success')}}
        </div>
        @endif

        <table class="table text-center">
            <tr>
                <th>الاسم</th>
                <th>الكمية</th>
                <th>السعر</th>
                <th>المجموع</th>
                <th></th>
                <th></th>
            </tr>
            @foreach ($order->orderProduct as $product)
            <tr>
                <th>
                    <p>{{$product->product->name_ar}}</p>
                </th>
                <th>
                    <p>
                        {{$product->quantity}}
                    </p>
                </th>
             
                <th>
                    <p class="">
                        {{$product->price}}
                    </p> 
                </th>
                <th>
                   <p>
                        {{$product->total}}
                   </p>
                </th>
                
            </tr>
            @endforeach
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th>{{$order->subtotal}}</th>
            </tr>

        </table>
        <a id="add_cart" class="btn btn-success addToCart" href="{{route('order.shipping',$order->id)}}" >
            <i class="mx-2 fas fa-shopping-cart"></i> شحن
       </a>
       
       <button class="btn btn-danger delete_product" product_id="{"> <i class="fas fa-trash"></i> الغاء</button>

    </div>


@endsection
